<?php
namespace app\admin\model;
use think\Model;
class Yingyong extends Model
{

	


}
